//
//  Person.h
//  OC-多态性
//
//  Created by Nusen_Liu on 2020/8/14.
//  Copyright © 2020 Nusen. All rights reserved.
//

//定义一个复合类Person
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

//前向导入
@class Tree;
@class Osier;
@class PineTree;


//定义一个万能的Person类
@interface Person : NSObject

@property(nonatomic, retain) NSString *name;
@property(nonatomic, assign) int age;
@property(nonatomic, retain) Tree *tree;

-(instancetype)initWithName:(NSString *)name andAge:(int)age;

@end

NS_ASSUME_NONNULL_END
