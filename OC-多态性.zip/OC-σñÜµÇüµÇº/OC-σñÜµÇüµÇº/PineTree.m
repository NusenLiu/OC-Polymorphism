//
//  PineTree.m
//  OC-多态性
//
//  Created by Nusen_Liu on 2020/8/14.
//  Copyright © 2020 Nusen. All rights reserved.
//

#import "PineTree.h"

@implementation PineTree

-(void)grow
{
    NSLog(@"子类2：松树四季常青");
}

@end
