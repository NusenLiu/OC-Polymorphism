//
//  PineTree.h
//  OC-多态性
//
//  Created by Nusen_Liu on 2020/8/14.
//  Copyright © 2020 Nusen. All rights reserved.
//

#import "Tree.h"

NS_ASSUME_NONNULL_BEGIN

@interface PineTree : Tree

//重写父类grow方法
-(void)grow;

@end

NS_ASSUME_NONNULL_END
