//
//  main.m
//  OC-多态性
//
//  Created by Nusen_Liu on 2020/8/14.
//  Copyright © 2020 Nusen. All rights reserved.
//

//  博主链接：https://www.cnblogs.com/liuzhi20101016/p/13499968.html



#import <UIKit/UIKit.h>
#import "AppDelegate.h"

//导入头文件（此时并没有导入它们的父类：Tree.h，因为继承关系，所以父类也是生效的）
#import "Osier.h"
#import "PineTree.h"

#import "Person.h"


//定义一个函数，用父类指针作形参
#warning 情况2
//void grow(Tree *t)
//{
//    [t grow];
//}

int main(int argc, char * argv[]) {
    NSString * appDelegateClassName;
    @autoreleasepool {
        // Setup code that might create autoreleased objects goes here.
//        appDelegateClassName = NSStringFromClass([AppDelegate class]);
        
#warning 情况1
        
        //父类的指针指向子类的对象
//        Tree *t1 = [[Osier alloc] init];
//        [t1 grow];
//        Tree *t2 = [[PineTree alloc] init];
//        [t2 grow];
//
//        Tree *t0 = [[Tree alloc]init];
//        [t0 grow];
        
        /**
         *  输出结果：子类1：柳树在春天发芽
         *          子类2：松树四季常青
         *          父类：树木生长
         */
        
#warning 情况2
//        Tree *t0 = [[Tree alloc] init];
//        grow(t0);
//
//        Tree *t1 = [[Osier alloc] init];
//        grow(t1);
//
//        Tree *t2 = [[PineTree alloc] init];
//        grow(t2);
        
        /**
         * 输出结果：   父类：树木生长
         *          子类1：柳树在春天发芽
         *          子类2：松树四季常青
         */
#warning 情况3
        Person *p = [[Person alloc]initWithName:@"小明" andAge:15];
        
        NSLog(@"%@", p);
        [p.tree grow];
        
        /**
         * 输出结果 ：name = 小明, age = 15
         *          子类2：松树四季常青
         */
        
        
    }
//    return UIApplicationMain(argc, argv, nil, appDelegateClassName);
    
    return 0;
}
