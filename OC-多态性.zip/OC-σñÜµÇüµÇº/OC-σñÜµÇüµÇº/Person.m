//
//  Person.m
//  OC-多态性
//
//  Created by Nusen_Liu on 2020/8/14.
//  Copyright © 2020 Nusen. All rights reserved.
//

#import "Person.h"
#import "Tree.h"
#import "Osier.h"
#import "PineTree.h"

@implementation Person

-(instancetype)initWithName:(NSString *)name andAge:(int)age
{
    if(self = [super init])
    {
        _name = name;
        _age = age;
        _tree = [[PineTree alloc] init];  //这里设置了_tree 要走的类，即 PineTree类，如果换成其他的类，最后的grow值也就不一样了
        
//        _tree = [[Osier alloc] init];
//         _tree = [[Tree alloc] init];
    }
    return self;
}

-(NSString *)description
{
    return [NSString stringWithFormat:@"name = %@, age = %i", _name, _age];
}

@end
