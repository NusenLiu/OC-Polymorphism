//
//  Tree.h
//  OC-多态性
//
//  Created by Nusen_Liu on 2020/8/14.
//  Copyright © 2020 Nusen. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Tree : NSObject

@property NSString *name;
@property int age;

-(void)grow;

@end

NS_ASSUME_NONNULL_END
